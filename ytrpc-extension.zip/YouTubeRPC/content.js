function getVideoData() {
    try {
        // Pobieramy tytuł z karty przeglądarki
        const pageTitle = document.title;
        
        // Usuwamy " - YouTube" z końca tytułu
        const title = pageTitle.replace(" - YouTube", "").trim();
        const url = window.location.href;

        console.log("Pobrane dane:", title, url); // Logowanie do konsoli

        // Zapisujemy dane do chrome.storage
        chrome.storage.local.set({ youtubeTitle: title, youtubeURL: url }, () => {
            console.log("Dane zapisane w chrome.storage");
        });
    } catch (error) {
        console.error("Błąd w getVideoData:", error);
    }
}

// Co 5 sekund pobieramy dane
setInterval(getVideoData, 5000);

// Obsługa zamknięcia strony
window.addEventListener("unload", () => {
    console.log("Strona YouTube została zamknięta");
    chrome.storage.local.remove(["youtubeTitle", "youtubeURL"], () => {
        console.log("Dane wyczyszczone z chrome.storage");
    });
});
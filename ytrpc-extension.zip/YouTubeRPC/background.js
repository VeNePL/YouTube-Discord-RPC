function setActivityToServer(title, url) {
    fetch("http://localhost:3000/update", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ title, url }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Błąd sieciowy: " + response.statusText);
        }
        return response.json();
    })
    .then(data => console.log("Dane wysłane:", data))
    .catch(error => console.error("Błąd:", error));
}

// Sprawdzamy, czy karta YouTube jest otwarta
function checkYouTubeTab() {
    chrome.tabs.query({ url: "*://www.youtube.com/watch?v=*" }, (tabs) => {
        if (tabs.length > 0) {
            console.log("Karta YouTube jest otwarta");
            // Wymuszamy uruchomienie content.js na już otwartej karcie
            tabs.forEach(tab => {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ["content.js"],
                }).then(() => {
                    console.log(`Wstrzyknięto content.js na karcie ${tab.id}`);
                }).catch(err => {
                    console.error("Błąd podczas wstrzykiwania content.js:", err);
                });
            });

            // Pobieramy dane z chrome.storage
            chrome.storage.local.get(["youtubeTitle", "youtubeURL"], (data) => {
                console.log("Dane z chrome.storage:", data); // Logowanie danych
                if (data.youtubeTitle && data.youtubeURL) {
                    setActivityToServer(data.youtubeTitle, data.youtubeURL);
                } else {
                    setActivityToServer(null, null); // Wyłącz aktywność RPC
                }
            });
        } else {
            console.log("Karta YouTube nie jest otwarta, wyłączam aktywność RPC");
            setActivityToServer(null, null); // Wyłącz aktywność RPC
        }
    });
}

// Sprawdzamy wszystkie karty podczas uruchamiania rozszerzenia
function checkAllTabsOnStartup() {
    console.log("Sprawdzam wszystkie karty podczas uruchamiania rozszerzenia");
    checkYouTubeTab();
}

// Co 5 sekund sprawdzamy, czy karta YouTube jest otwarta
setInterval(checkYouTubeTab, 5000);

// Obsługa zamknięcia karty
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
    console.log("Karta została zamknięta, sprawdzam czy to była karta YouTube");
    checkYouTubeTab();
});

// Obsługa zmiany URL na karcie
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url && changeInfo.url.includes("youtube.com/watch?v=")) {
        console.log("URL karty YouTube został zmieniony");
        checkYouTubeTab();
    }
});

// Sprawdzamy wszystkie karty podczas uruchamiania rozszerzenia
checkAllTabsOnStartup();